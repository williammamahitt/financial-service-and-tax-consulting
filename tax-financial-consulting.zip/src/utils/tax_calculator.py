def calculate_pph21(gaji_bulanan: float, status: str = "TK0") -> float:
    """
    Hitung PPh 21 berdasarkan gaji bulanan (sederhana).
    Status TK0 = Tidak Kawin, 0 Tanggungan
    """
    ptkp = {
        "TK0": 54000000,  # PTKP Tahunan
        "K0": 58500000,
        "K1": 63000000
    }

    gaji_tahunan = gaji_bulanan * 12
    pkp = max(0, gaji_tahunan - ptkp.get(status, 54000000))

    pajak = 0
    if pkp <= 50000000:
        pajak = pkp * 0.05
    elif pkp <= 250000000:
        pajak = 50000000 * 0.05 + (pkp - 50000000) * 0.15
    elif pkp <= 500000000:
        pajak = 50000000 * 0.05 + 200000000 * 0.15 + (pkp - 250000000) * 0.25
    else:
        pajak = (50000000 * 0.05 + 200000000 * 0.15 +
                 250000000 * 0.25 + (pkp - 500000000) * 0.30)

    return pajak / 12  # per bulan
