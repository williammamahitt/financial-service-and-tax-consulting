from utils.tax_calculator import calculate_pph21

if __name__ == "__main__":
    gaji = 10000000  # contoh gaji bulanan
    pajak = calculate_pph21(gaji, status="TK0")
    print(f"PPh21 per bulan: Rp {pajak:,.2f}")
