import pytest
from src.utils.tax_calculator import calculate_pph21

def test_pph21_tk0():
    pajak = calculate_pph21(10000000, "TK0")
    assert pajak > 0

def test_pph21_k1():
    pajak = calculate_pph21(20000000, "K1")
    assert pajak > 0
