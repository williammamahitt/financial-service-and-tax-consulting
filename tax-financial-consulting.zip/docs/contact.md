# Kontak

- Website: [contoh.com](https://contoh.com)
- Email: info@contoh.com
- Telepon: +62-xxx-xxxx-xxx
- Alamat: Jl. Pajak Sejahtera No. 123, Jakarta
