# Profil Perusahaan

**Nama Perusahaan**: PT Konsultan Pajak & Keuangan Sejahtera  
**Bidang Usaha**: Jasa Konsultasi Pajak, Akuntansi, dan Perencanaan Keuangan  
**Visi**: Menjadi mitra terpercaya dalam mengelola pajak & keuangan secara profesional  
**Misi**:
1. Memberikan solusi perpajakan yang tepat dan efisien
2. Membantu klien mencapai stabilitas keuangan
3. Menyediakan layanan berbasis teknologi dan transparansi
